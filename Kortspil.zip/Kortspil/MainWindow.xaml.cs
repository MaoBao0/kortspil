﻿using System;
using System.Diagnostics.Eventing.Reader;
using System.Windows;
using System.Windows.Media.Imaging;

namespace Kortspil
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// 
    /// Kortene er hentet fra https://acbl.mybigcommerce.com/52-playing-cards/
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            int kortnummer = Convert.ToInt32(Kort.Text);
            string filnavn = FindBillede(kortnummer);
            string url = $"/Billeder/{filnavn}";
            Uri uri = new (url, UriKind.Relative);
            BitmapImage image = new(uri);
           
            Billede.Source = image;
            
        }

        private string FindBillede(int kortnummer)
        {
            //korttype
            string korttype = "";
            if (kortnummer >= 1 && kortnummer <= 13)
            {
                korttype = "Spar";
            }
            else if (kortnummer >= 14 && kortnummer <= 26)
            {
                korttype = "Ruder";
                kortnummer -= 13;
            }
            else if (kortnummer >= 27 && kortnummer <= 39)
            {
                korttype = "Klør";
                kortnummer -= 26;
            }
            else
            {
                korttype = "Hjerter";
                kortnummer -= 39;
            }

            //korttal
            string korttal = "";
            if (kortnummer == 1)
            {
                korttal = "Es";
            }
            else if (kortnummer == 11)
            {
                korttal = "Knægt";
            }
            else if (kortnummer == 12)
            {
                korttal = "Dame";
            }
            else if (kortnummer == 13)
            {
                korttal = "Konge";
            }
            else if (kortnummer >= 2 && kortnummer <= 10)
            {
                korttal = kortnummer.ToString();
            }
            else
            return $"{korttal}-{korttype}.jpg";
        }
    }
}
